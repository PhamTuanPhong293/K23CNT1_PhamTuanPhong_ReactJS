import React, { Component } from 'react'

export default class ptpApp extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
